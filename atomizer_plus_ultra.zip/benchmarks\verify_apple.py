"""verify_apple.py — Edge-case verification for the hardened NMMU."""

import json
import os
import re
import sys

import PyPDF2
import ollama
from charon.core import L1Cache, rank_triples_by_importance
from cerberus.core import build_source_graph, verify_claim
from shared.extractor import extract_knowledge_triples
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from shared.triple import KnowledgeTriple

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def get_embedder():
    return SentenceTransformer("all-MiniLM-L6-v2")


SYSTEM_INSTRUCTION = """You are the NMMU (Neural Memory Management Unit), a strict hardware instruction decoder. 
You do not converse. You do not explain your thoughts. 

You have two operating modes. You MUST output ONLY the mode's payload, NEVER the mode name itself.

1. CACHE HIT (Answer Synthesis):
   If the L1 Cache (Context) contains the answer to the user's query, output the final answer directly.
   
2. CACHE MISS (Memory Fault):
   If the answer is NOT in the L1 Cache, you MUST trigger an L2 Page Fault by outputting STRICTLY a JSON object matching this schema. Do not output any text before or after the JSON:
{
    "tool": "search_memory",
    "keyword": "exact_semantic_keyword_to_search"
}

Examples:
Input: "What is an apple?"
Assistant: "An apple is a round, edible fruit."

Input: "Who is King Rerir?"
Assistant: {"tool": "search_memory", "keyword": "King Rerir"}

Input: "What is the formula for photosynthesis?" (If not in L1 Cache)
Assistant: {"tool": "search_memory", "keyword": "photosynthesis formula"}

[SYSTEM: TOOL RESULT: No memory hit for keyword]
Assistant: INSUFFICIENT DATA. The source document does not contain this information."""

OLLAMA_MODEL = "phi3.5"
OLLAMA_OPTIONS = {
    "temperature": 0.0,
    "num_predict": 512,
    "repeat_penalty": 1.05,
}
FORCE_SEARCH_PROMPT = "CACHE MISS. You must use the search_memory tool now."

STATE_BREAKER = (
    "\n\nCOMMAND: Search complete. You MUST synthesize the final answer now "
    "using ONLY the tool result above. DO NOT output JSON. DO NOT call "
    "search_memory again. If the result is empty, reply with "
    "'INSUFFICIENT DATA'."
)


def query_l2_memory(keyword, source_graph, embedder):
    if source_graph is None or not keyword:
        return ""
    keyword_vector = embedder.encode(keyword)
    graph = source_graph.graph
    best_node = None
    best_score = -1.0
    for node, data in graph.nodes(data=True):
        if "vector" in data and data["vector"] is not None:
            sim = cosine_similarity([keyword_vector], [data["vector"]])[0][0]
            if sim > best_score:
                best_score = sim
                best_node = node
    if best_score < 0.60 or best_node is None:
        return ""
    edge_lines = []
    seen = set()
    for s, o, d in graph.out_edges(best_node, data=True):
        v = str((d or {}).get("verb", "")).strip()
        key = (str(s), v, str(o))
        if key not in seen:
            seen.add(key)
            edge_lines.append(f"{s} {v} {o}".strip())
    for s, o, d in graph.in_edges(best_node, data=True):
        v = str((d or {}).get("verb", "")).strip()
        key = (str(s), v, str(o))
        if key not in seen:
            seen.add(key)
            edge_lines.append(f"{s} {v} {o}".strip())
    return " | ".join(edge_lines)


def call_model(messages):
    msgs = list(messages)
    msgs.append({"role": "assistant", "content": ""})
    resp = ollama.chat(model=OLLAMA_MODEL, messages=msgs, options=OLLAMA_OPTIONS)
    content = resp.get("message", {}).get("content", "").strip()
    content = re.sub(
        r"^(MODE \d:|CACHE (HIT|MISS)( \(Memory Fault\))?:)",
        "", content, flags=re.IGNORECASE,
    ).strip()
    return content


def extract_keyword(content):
    m = re.search(r"\{.*\}", content, re.DOTALL)
    if m:
        try:
            parsed = json.loads(m.group(0))
            if isinstance(parsed, dict) and parsed.get("tool") == "search_memory":
                return parsed.get("keyword")
        except Exception:
            pass
    return None


def run_cerberus(final_answer, source_graph):
    """Return True unless any triple is a *contradiction* (active hallucination).
    Neutral triples (paraphrases) pass through."""
    if source_graph is None:
        return True
    triples = extract_knowledge_triples(final_answer)
    if not triples:
        return True
    has_contradiction = False
    for triple in triples:
        verdict = verify_claim(triple, source_graph)
        if verdict.is_verified:
            print(f"  CERBERUS CLEAN: [{triple.as_text()}]")
        elif verdict.label == "contradiction":
            has_contradiction = True
            print(f"  CERBERUS CONTRADICTION: [{triple.as_text()}] — {verdict.reason}")
        else:
            print(f"  CERBERUS NEUTRAL: [{triple.as_text()}] — {verdict.reason}")
    return not has_contradiction


def run_test(question, source_graph, embedder, l1_cache):
    print(f"\n{'='*60}")
    print(f"Q: {question}")
    print("=" * 60)

    facts = [entry.text for entry in l1_cache.set_facts.values()]
    facts_block = "\n".join(f"- {f}" for f in facts[:15]) if facts else "<empty>"
    user_content = f"L1 Context (Facts):\n{facts_block}\n\nCurrent Question: {question}"

    messages = [
        {"role": "system", "content": SYSTEM_INSTRUCTION},
        {"role": "user", "content": user_content},
    ]

    content = call_model(messages)
    keyword = extract_keyword(content)

    # Force search for short non-JSON replies
    if not keyword and (not content or len(content.split()) < 4):
        print(f"  Short reply detected: '{content}' — forcing search")
        messages.append({"role": "assistant", "content": content})
        messages.append({"role": "user", "content": FORCE_SEARCH_PROMPT})
        content = call_model(messages)
        keyword = extract_keyword(content)

    tool_calls = 0
    if keyword:
        tool_calls = 1
        print(f"  MEMORY FAULT → keyword='{keyword}'")
        tool_output = query_l2_memory(keyword, source_graph, embedder)
        if not tool_output:
            tool_output = f"No memory hit for keyword: {keyword}"
        print(f"  TOOL RESULT: {tool_output[:120]}...")

        messages.append({"role": "assistant", "content": content})
        messages.append({
            "role": "user",
            "content": f"TOOL RESULT: {tool_output}{STATE_BREAKER}",
        })
        final_answer = call_model(messages)
    else:
        print(f"  CACHE HIT (direct answer)")
        final_answer = content

    # Cerberus intercept
    is_clean = run_cerberus(final_answer, source_graph)
    if not is_clean:
        final_answer = (
            "🚨 NLI CERBERUS BLOCK: My policy engine attempted to answer this, "
            "but the local DeBERTa-v3 verification failed. The source document "
            "does not support this claim."
        )

    print(f"  FINAL ANSWER: {final_answer}")
    return final_answer, tool_calls, is_clean


def main():
    pdf_path = "Apple.pdf"
    print(f"Loading {pdf_path}...")
    reader = PyPDF2.PdfReader(pdf_path)
    all_triples = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            all_triples.extend(extract_knowledge_triples(text))
    print(f"Extracted {len(all_triples)} triples.")

    embedder = get_embedder()
    source_graph = build_source_graph(all_triples, embedder=embedder)

    l1_cache = L1Cache(budgets={"facts": 100})
    ranked = rank_triples_by_importance(all_triples)
    for triple, score in ranked:
        l1_cache.add_fact(triple, pagerank_score=score)

    # ── Original 3 tests ──
    original_tests = [
        ("What is the Old English origin of the word 'apple'?", "æppel"),
        ("When was the apple genome first sequenced?", "2010"),
        ("What happens to open apple blossoms at −2∘C?", "damag"),
    ]

    # ── Edge case tests ──
    edge_cases = [
        ("What is the estimated genome size of an apple?", "650"),
        ("Who first classified pears, apples, and quinces into the genus Pyrus?", "Linnaeus"),
        ("How many moons does the Malus domestica planet have?", "INSUFFICIENT"),
        ("What is the chemical formula for photosynthesis?", "INSUFFICIENT"),
        ("What happened in April 2017 regarding the naming of apples?", None),  # No single keyword — just check no loop
        ("Name three volatile compounds that contribute to apple scent.", None),
    ]

    all_tests = original_tests + edge_cases
    results = []
    total_tool_calls = 0

    for question, expected_substr in all_tests:
        answer, calls, clean = run_test(question, source_graph, embedder, l1_cache)
        total_tool_calls += calls
        if expected_substr:
            found = expected_substr.lower() in answer.lower()
        else:
            found = len(answer) > 10  # Just verify we got a non-trivial response
        results.append((question, answer, calls, clean, found))

    print("\n" + "=" * 70)
    print("FULL TEST SUMMARY")
    print("=" * 70)
    passed = 0
    for q, a, c, clean, found in results:
        status = "✅ PASS" if found else "❌ FAIL"
        if found:
            passed += 1
        cerberus_str = "CLEAN" if clean else "BLOCKED"
        tool_str = f"Tool={c}" if c else "Cache"
        print(f"[{status}] [{tool_str}] [{cerberus_str}]")
        print(f"  Q: {q}")
        print(f"  A: {a[:100]}...")
        print()

    print(f"Results: {passed}/{len(results)} passed")
    print(f"Total Tool Calls: {total_tool_calls}")


if __name__ == "__main__":
    main()
