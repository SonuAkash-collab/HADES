"""Charon benchmark package."""
