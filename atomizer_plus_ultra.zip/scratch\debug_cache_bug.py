import os
from shared.extractor import extract_source_triples
import pymupdf4llm
import re

def test_extraction(pdf_path):
    print(f"Testing extraction for {pdf_path}")
    full_text = pymupdf4llm.to_markdown(pdf_path, page_chunks=False)
    print(f"Original text length: {len(full_text)}")
    # Clean up text like in the benchmark
    full_text = re.sub(r'\s+', ' ', full_text).strip()
    print(f"Cleaned text length: {len(full_text)}")
    print(f"Text start: {full_text[:200]}...")
    
    triples = extract_source_triples(full_text)
    print(f"Extracted {len(triples)} triples")
    if len(triples) > 0:
        print("First 5 triples:")
        for t in triples[:5]:
            print(f"  {t.subject} - {t.verb} - {t.object}")
    else:
        print("WARNING: No triples extracted!")

if __name__ == "__main__":
    nips_path = "data/NIPS-2017-attention-is-all-you-need-Paper-1-4.pdf"
    nvidia_path = "data/corporate-nvidia-in-brief-pdf-august-3374577-FINAL.pdf"
    
    if os.path.exists(nips_path):
        test_extraction(nips_path)
    else:
        print(f"Not found: {nips_path}")
        
    if os.path.exists(nvidia_path):
        test_extraction(nvidia_path)
    else:
        print(f"Not found: {nvidia_path}")
