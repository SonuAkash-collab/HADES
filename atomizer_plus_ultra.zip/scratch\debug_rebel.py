import sys
import os
sys.path.append(os.getcwd())
from shared.extractor import _extract_rebel_triples
from shared.triple import KnowledgeTriple

text = "The apple tree comes from southern Kazakhstan. Its fruits have become better over thousands of years."
triples = _extract_rebel_triples(text)
print(f"Extracted {len(triples)} triples:")
for t in triples:
    print(f" - {t.subject} | {t.verb} | {t.object}")
