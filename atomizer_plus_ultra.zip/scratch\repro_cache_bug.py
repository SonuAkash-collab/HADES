from benchmarks.apple_pdf_benchmark import ingest_pdf
import os
import json

def reproduce_cache_issue():
    pdf_paths = [
        "data/NIPS-2017-attention-is-all-you-need-Paper-1-4.pdf",
        "data/corporate-nvidia-in-brief-pdf-august-3374577-FINAL.pdf"
    ]
    
    for pdf_path in pdf_paths:
        base_name = os.path.basename(pdf_path)
        cache_path = os.path.join("benchmarks/cache", f"{base_name}.json")
        
        if os.path.exists(cache_path):
            print(f"Deleting existing cache: {cache_path}")
            os.remove(cache_path)
            
        print(f"Ingesting {pdf_path} to re-generate cache...")
        ingest_pdf(pdf_path)
        
        if os.path.exists(cache_path):
            with open(cache_path, "r") as f:
                data = json.load(f)
                count = len(data.get("triples", []))
                print(f"Re-generated cache {cache_path} has {count} triples")
                if count == 0:
                    print("!!! REPRODUCED: Cache is EMPTY !!!")
        else:
            print(f"Error: Cache file {cache_path} was not created")

if __name__ == "__main__":
    reproduce_cache_issue()
