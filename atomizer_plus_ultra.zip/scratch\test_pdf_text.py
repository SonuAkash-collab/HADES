import pymupdf4llm
import re
import os

STOP_MARKERS = (
    '## references', '## further reading', '## see also',
    '## external links', '## bibliography', '# references',
)

def _safe_print(msg: str, **kwargs):
    try:
        print(msg, **kwargs)
    except UnicodeEncodeError:
        print(msg.encode('ascii', 'ignore').decode('ascii'), **kwargs)

def test_pdf_text(pdf_path):
    _safe_print(f"\n--- Testing {pdf_path} ---")
    if not os.path.exists(pdf_path):
        _safe_print("File not found")
        return
        
    full_text = pymupdf4llm.to_markdown(pdf_path, page_chunks=False)
    _safe_print(f"Raw length: {len(full_text)}")
    
    # Clean up text like in the benchmark
    full_lower = full_text.lower()
    found_marker = False
    for marker in STOP_MARKERS:
        idx = full_lower.find(marker)
        if idx != -1:
            _safe_print(f"Found marker '{marker}' at index {idx}")
            full_text = full_text[:idx]
            found_marker = True
            break
            
    if not found_marker:
        _safe_print("No STOP_MARKERS found")
        
    full_text = re.sub(r'==> picture \[.*?\] intentionally omitted <==', '', full_text)
    full_text = re.sub(r'\s+', ' ', full_text).strip()
    
    _safe_print(f"Final length: {len(full_text)}")
    if len(full_text) > 0:
        _safe_print(f"First 500 chars: {full_text[:500]}...")
    else:
        _safe_print("WARNING: Final text is EMPTY!")

if __name__ == "__main__":
    test_pdf_text("data/NIPS-2017-attention-is-all-you-need-Paper-1-4.pdf")
    test_pdf_text("data/corporate-nvidia-in-brief-pdf-august-3374577-FINAL.pdf")
    test_pdf_text("data/Apple-1.pdf")
